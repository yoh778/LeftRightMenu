//
//  AppDelegate.h
//  MyLeftMenuObjC
//
//  Created by PromptNow on 6/5/17.
//  Copyright © 2017 StunStudio. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

