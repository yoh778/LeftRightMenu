//
//  ViewController.m
//  MyLeftMenuObjC
//
//  Created by PromptNow on 6/5/17.
//  Copyright © 2017 StunStudio. All rights reserved.
//

#import "ViewController.h"

@interface ViewController () <MyMenuDelegate>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.delegate = self;
    [self setMenu];
    
    [self setTitle:@"XXXXX"];
    [self setColorBar:[UIColor lightGrayColor]];
    [self setTextTitleColor:[UIColor whiteColor]];
    [self setRightMenuWithText:@"Right" color:[UIColor whiteColor]];
    UIImage *mm = [UIImage imageNamed:@"Hamburger.png"];
    [self setImgLeftMenu:mm];
    [self setLeftMenuColorBG:[UIColor darkGrayColor]];
    
    [self setSlideMenu:NO];
}

-(void) setMenu {
    UIView *v1 = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 0, 100)];
    v1.backgroundColor = [UIColor redColor];
    [self AddMenu:v1];
    
    UIView *v2 = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 0, 30)];
    v2.backgroundColor = [UIColor yellowColor];
    [self AddMenu:v2];
    
    [self AddMenuTextOnly:@"EASY MODE"];
    [self AddMenuTextOnly:@"EASY MODE 111111111111111111111111111111111111111"];
    [self AddMenuTextOnly:@"EASY MODE 11111111"];
    
    UIView *v3 = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 0, 100)];
    v3.backgroundColor = [UIColor brownColor];
    [self AddMenu:v3];
    
    [self AddMenuTextOnly:@"EASY MODE 1111111111111111"];
    [self AddMenuTextOnly:@"EASY MODE 11111111"];
    [self RefreshMenu];
    
}
- (void) TouchMenuDidStart:(NSInteger) rowTouch{
    NSInteger m = rowTouch;
    NSLog(@"selected %d row", m);
}
    
-(void)TouchRightTop{
    NSLog(@"TouchRightTop");
}
-(void)TouchLeftTop{
    NSLog(@"TouchLeftTop");
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
