//
//  ViewController.swift
//  MyLeftMenuSwift
//
//  Created by PromptNow on 6/5/17.
//  Copyright © 2017 StunStudio. All rights reserved.
//

import UIKit

class ViewController: MyLeftMenu , MyMenuDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.delegate = self
        self.setMenu()
        
        
        self.setTitle("XXXXX");
        self.setColorBar(UIColor.lightGray)
        self.setLeftMenuColorBG(UIColor.darkGray)
        self.setTextTitleColor(UIColor.white)
        
        let im = UIImage.init(named: "Hamburger.png")
        //Ex Slide Form Left
        //self.setImg(im)
        //self.setRightMenuWithText("Right", color: UIColor.white)
        
        //Ex Slide Form Right
        self.setLeftMenuWithText("Left", color: UIColor.white)
        self.setImgRight(im)
        self.setSlide(true)
    }
    
    func setMenu() {
        let v1 = UIView.init(frame: CGRect(x: 0, y: 0, width: 0, height: 100))
        v1.backgroundColor = UIColor.red
        self.add(v1)
        
        let v2 = UIView.init(frame: CGRect(x: 0, y: 0, width: 0, height: 30))
        v2.backgroundColor = UIColor.yellow
        self.add(v2)
        
        self.addTextOnly("EASY MODE")
        self.addTextOnly("EASY MODE 111111111111111111111111111111111111111")
        self.addTextOnly("EASY MODE 11111111")
        self.addTextOnly("EASY MODE")
        
        let v3 = UIView.init(frame: CGRect(x: 0, y: 0, width: 0, height: 100))
        v3.backgroundColor = UIColor.brown
        self.add(v3)
        
        self.addTextOnly("EASY MODE 11111111111111")
        self.addTextOnly("EASY MODE 11111111")
        self.refreshMenu()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func touchLeftTop() {
        print("touchLeftTop")
    }
    func touchRightTop() {
        print("touchRightTop")
    }
    
    func touchMenuDidStart(_ rowTouch: Int) {
        print("menu %d", rowTouch)
    }
}

